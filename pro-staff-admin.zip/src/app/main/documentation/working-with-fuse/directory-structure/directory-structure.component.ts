import { Component } from '@angular/core';

@Component({
    selector   : 'docs-working-with-fuse-directory-structure',
    templateUrl: './directory-structure.component.html',
    styleUrls  : ['./directory-structure.component.scss']
})
export class DocsWorkingWithFuseDirectoryStructureComponent
{
    constructor()
    {
    }
}
