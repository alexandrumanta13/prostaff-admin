import { Component } from '@angular/core';

@Component({
    selector   : 'docs-working-with-fuse-material-theming',
    templateUrl: './material-theming.component.html',
    styleUrls  : ['./material-theming.component.scss']
})
export class DocsWorkingWithFuseMaterialThemingComponent
{
    constructor()
    {
    }
}
