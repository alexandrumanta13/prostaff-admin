import { Component } from '@angular/core';

@Component({
    selector   : 'docs-working-with-fuse-page-layouts',
    templateUrl: './page-layouts.component.html',
    styleUrls  : ['./page-layouts.component.scss']
})
export class DocsWorkingWithFusePageLayoutsComponent
{
    constructor()
    {
    }
}
