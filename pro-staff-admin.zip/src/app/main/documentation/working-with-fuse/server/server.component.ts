import { Component } from '@angular/core';

@Component({
    selector   : 'docs-working-with-fuse-server',
    templateUrl: './server.component.html',
    styleUrls  : ['./server.component.scss']
})
export class DocsWorkingWithFuseServerComponent
{
    constructor()
    {
    }
}
