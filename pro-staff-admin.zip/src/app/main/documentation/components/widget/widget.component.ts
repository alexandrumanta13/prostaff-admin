import { Component } from '@angular/core';

@Component({
    selector   : 'docs-components-widget',
    templateUrl: './widget.component.html',
    styleUrls  : ['./widget.component.scss']
})
export class DocsComponentsWidgetComponent
{
    /**
     * Constructor
     */
    constructor()
    {

    }
}
