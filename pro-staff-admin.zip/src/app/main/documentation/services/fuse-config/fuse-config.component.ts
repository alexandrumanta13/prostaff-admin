import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-config-service-docs',
    templateUrl: './fuse-config.component.html',
    styleUrls  : ['./fuse-config.component.scss']
})
export class FuseConfigServiceDocsComponent
{
    /**
     * Constructor
     */
    constructor()
    {

    }
}
