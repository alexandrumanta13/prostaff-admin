import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-splash-screen-service-docs',
    templateUrl: './fuse-splash-screen.component.html',
    styleUrls  : ['./fuse-splash-screen.component.scss']
})
export class FuseSplashScreenServiceDocsComponent
{
    /**
     * Constructor
     */
    constructor()
    {

    }
}
