import { Component } from '@angular/core';

@Component({
    selector   : 'docs-introduction',
    templateUrl: './introduction.component.html',
    styleUrls  : ['./introduction.component.scss']
})
export class DocsGettingStartedIntroductionComponent
{
    constructor()
    {
    }
}
