import { Component } from '@angular/core';

@Component({
    selector   : 'docs-installation',
    templateUrl: './installation.component.html',
    styleUrls  : ['./installation.component.scss']
})
export class DocsGettingStartedInstallationComponent
{
    constructor()
    {
    }
}
