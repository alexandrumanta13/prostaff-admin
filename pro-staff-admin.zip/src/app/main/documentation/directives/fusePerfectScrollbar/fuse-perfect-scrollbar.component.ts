import { Component } from '@angular/core';

@Component({
    selector   : 'docs-directives-fuse-perfect-scrollbar',
    templateUrl: './fuse-perfect-scrollbar.component.html',
    styleUrls  : ['./fuse-perfect-scrollbar.component.scss']
})
export class DocsDirectivesFusePerfectScrollbarComponent
{
    constructor()
    {
    }
}
