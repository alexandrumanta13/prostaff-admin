import { Component } from '@angular/core';

@Component({
    selector   : 'docs-directives-fuse-inner-scroll',
    templateUrl: './fuse-inner-scroll.component.html',
    styleUrls  : ['./fuse-inner-scroll.component.scss']
})
export class DocsDirectivesFuseInnerScrollComponent
{
    constructor()
    {
    }
}
