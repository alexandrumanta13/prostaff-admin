import { Component, ViewEncapsulation } from '@angular/core';

@Component({
    selector     : 'pricing-style-1',
    templateUrl  : './style-1.component.html',
    styleUrls    : ['./style-1.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class PricingStyle1Component
{
    /**
     * Constructor
     */
    constructor()
    {

    }

}
