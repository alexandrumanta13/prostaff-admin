import { Component } from '@angular/core';

@Component({
    selector   : 'helper-classes-padding-margin',
    templateUrl: './padding-margin.component.html',
    styleUrls  : ['./padding-margin.component.scss']
})
export class HelperClassesPaddingMarginComponent
{
    /**
     * Constructor
     */
    constructor()
    {

    }
}
