import { Component } from '@angular/core';

@Component({
    selector   : 'simple-full-width-tabbed-1',
    templateUrl: './full-width-tabbed-1.component.html',
    styleUrls  : ['./full-width-tabbed-1.component.scss']
})
export class SimpleFullWidthTabbed1Component
{
    /**
     * Constructor
     */
    constructor()
    {
    }

}
