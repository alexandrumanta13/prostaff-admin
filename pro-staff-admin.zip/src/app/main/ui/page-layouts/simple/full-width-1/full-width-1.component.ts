import { Component } from '@angular/core';

@Component({
    selector   : 'simple-fullwidth-1',
    templateUrl: './full-width-1.component.html',
    styleUrls  : ['./full-width-1.component.scss']
})
export class SimpleFullWidth1Component
{
    /**
     * Constructor
     */
    constructor()
    {
    }
}
