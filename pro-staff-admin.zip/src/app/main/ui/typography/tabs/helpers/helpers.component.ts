import { Component } from '@angular/core';

@Component({
    selector   : 'typography-helpers',
    templateUrl: './helpers.component.html',
    styleUrls  : ['./helpers.component.scss']
})
export class TypographyHelpersComponent
{
    /**
     * Constructor
     */
    constructor()
    {

    }
}
